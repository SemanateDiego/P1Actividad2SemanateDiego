package com.mycompany.p1actividad2semaantediego;

import java.util.List;
import java.util.Scanner;

public class P1Actividad2SemaanteDiego {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String archivoCSV = "productos.csv";
        int opcion;

        do {
            System.out.println("\n--- MENU DE PRODUCTOS ---");
            System.out.println("1. Agregar producto");
            System.out.println("2. Eliminar producto");
            System.out.println("3. Buscar producto");
            System.out.println("4. Ver productos");
            System.out.println("5. Leer desde archivo CSV");
            System.out.println("0. Salir");
            System.out.print("Seleccione una opcion: ");
            opcion = sc.nextInt();
            sc.nextLine(); // limpiar buffer

            switch (opcion) {
                case 1:
                    int idCategoria;
                    do {
                        System.out.print("Ingrese el ID de la categoria (mayor que 0): ");
                        idCategoria = sc.nextInt();
                        if (idCategoria <= 0) {
                            System.out.println("Error: El ID debe ser mayor que 0.");
                        }
                    } while (idCategoria <= 0);
                    sc.nextLine(); // limpiar buffer

                    String nombreCategoria;
                    do {
                        System.out.print("Ingrese el nombre de la categoria: ");
                        nombreCategoria = sc.nextLine();
                        if (nombreCategoria.trim().isEmpty() || ! nombreCategoria.matches("[A-Za-zÁÉÍÓÚáéíóúñÑ\\s]+")) {
                            System.out.println("Error: Nombre invalido. Solo letras y espacios.");
                            nombreCategoria = "";
                        }
                    } while (nombreCategoria.isEmpty());

                    String codigo;
                    do {
                        System.out.print("Ingrese el codigo del producto: ");
                        codigo = sc.nextLine();
                        if (codigo.trim().isEmpty() || !codigo.matches("[A-Za-z0-9]+")) {
                            System.out.println("Error: El codigo solo debe contener letras y numeros.");
                            codigo = "";
                        }
                    } while (codigo.isEmpty());

                    String nombreProducto;
                    do {
                        System.out.print("Ingrese el nombre del producto: ");
                        nombreProducto = sc.nextLine();
                        if (nombreProducto.trim().isEmpty() || ! nombreProducto.matches("[A-Za-zÁÉÍÓÚáéíóúñÑ\\s]+")) {
                            System.out.println("Error: El nombre no puede contener numeros ni caracteres invalidos.");
                            nombreProducto = "";
                        }
                    } while (nombreProducto.isEmpty());

                    double precio;
                    do {
                        System.out.print("Ingrese el precio del producto (mayor a 0): ");
                        precio = sc.nextDouble();
                        if (precio <= 0) {
                            System.out.println("Error: El precio debe ser mayor que 0.");
                        }
                    } while (precio <= 0);

                    Producto nuevo = new Producto(codigo, nombreProducto, precio, idCategoria, nombreCategoria);
                    nuevo.guardarEnCSV(archivoCSV);
                    break;

                case 2:
                    System.out.print("Ingrese el codigo del producto a eliminar: ");
                    String codigoEliminar = sc.nextLine();
                    boolean eliminado = Producto.eliminarProductoPorCodigoCSV(archivoCSV, codigoEliminar);
                    if (!eliminado) {
                        System.out.println("No se encontro el producto con ese codigo.");
                    }
                    break;

                case 3:
                    System.out.print("Ingrese el codigo del producto a buscar: ");
                    String codigoBuscar = sc.nextLine();
                    Producto encontrado = Producto.buscarProductoPorCodigoCSV(archivoCSV, codigoBuscar);
                    if (encontrado != null) {
                        encontrado.mostrarResumen();
                    } else {
                        System.out.println("Producto no encontrado.");
                    }
                    break;

                case 4:
                    Producto.mostrarProductosDesdeCSV(archivoCSV);
                    break;

                case 5:
                    System.out.println("Leyendo productos desde el archivo CSV...");
                    Producto.mostrarProductosDesdeCSV(archivoCSV);
                    break;

                case 0:
                    System.out.println("Saliendo del programa.");
                    break;

                default:
                    System.out.println("Opcion invalida.");
            }

        } while (opcion != 0);

        sc.close();
    }
}

