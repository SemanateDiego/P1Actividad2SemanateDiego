package com.mycompany.p1actividad2semaantediego;

public class Categoria {
    private int id;
    private String nombre;

    // Constructor usando setters para activar validaciones
    public Categoria(int id, String nombre) {
        setId(id);           
        setNombre(nombre);   
    }

    // Getters y setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        try {
            if (id > 0) {
                this.id = id;
            } else {
                throw new IllegalArgumentException("El ID debe ser mayor que 0.");
            }
        } catch (IllegalArgumentException e) {
            System.out.println("Error: " + e.getMessage());
            this.id = 1; // Valor por defecto mínimo válido
        }
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        try {
            if (nombre != null && !nombre.trim().isEmpty()) {
                if (nombre.matches("[A-Za-zÁÉÍÓÚáéíóúñÑ\\s]+")) {
                    this.nombre = nombre;
                } else {
                    throw new IllegalArgumentException("El nombre de la categoría contiene caracteres no válidos.");
                }
            } else {
                throw new IllegalArgumentException("El nombre de la categoría no puede estar vacío.");
            }
        } catch (IllegalArgumentException e) {
            System.out.println("Error: " + e.getMessage());
            this.nombre = "NombreCategoriaInvalido";
        }
    }
}
