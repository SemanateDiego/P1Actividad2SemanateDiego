package com.mycompany.p1actividad2semaantediego;
import java.io.*;
import java.util.*;
public class Producto extends Categoria {
    private String codigo;
    private String nombreProducto;
    private double precio;
    // Constructor
    public Producto(String codigo, String nombreProducto, double precio, int id, String nombre) {
        super(id, nombre);
        setCodigo(codigo);              
        setNombreProducto(nombreProducto);
        setPrecio(precio);
    }
    // Getters y setters
    public String getCodigo() {
        return codigo;
    }
    public void setCodigo(String codigo) {
        try {
            if (codigo != null && !codigo.trim().isEmpty()) {
                if (codigo.matches("[A-Za-z0-9]+")) {
                    this.codigo = codigo;
                } else {
                    throw new IllegalArgumentException("El codigo solo debe contener letras y numeros.");
                }
            } else {
                throw new IllegalArgumentException("El codigo no puede estar vacio.");
            }
        } catch (IllegalArgumentException e) {
            System.out.println("Error: " + e.getMessage());
            this.codigo = "CodigoInvalido";
        }
    }

    public String getNombreProducto() {
        return nombreProducto;
    }

    public void setNombreProducto(String nombreProducto) {
        try {
            if (nombreProducto != null && !nombreProducto.trim().isEmpty()) {
                if (nombreProducto.matches("[A-Za-zÁÉÍÓÚáéíóúñÑ\\s]+")) {
                    this.nombreProducto = nombreProducto;
                } else {
                    throw new IllegalArgumentException("El nombre no puede contener numeros ni caracteres invalidos.");
                }
            } else {
                throw new IllegalArgumentException("El nombre del producto no puede estar vacio.");
            }
        } catch (IllegalArgumentException e) {
            System.out.println("Error: " + e.getMessage());
            this.nombreProducto = "NombreProductoInvalido";
        }
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        try {
            if (precio > 0) {
                this.precio = precio;
            } else {
                throw new IllegalArgumentException("El precio debe ser mayor que 0.");
            }
        } catch (IllegalArgumentException e) {
            System.out.println("Error: " + e.getMessage());
            this.precio = 0.01;
        }
    }

    public void mostrarResumen() {
        System.out.println("Codigo del producto: " + codigo);
        System.out.println("Nombre del producto: " + nombreProducto);
        System.out.println("Precio: $" + precio);
        System.out.println("Categoria: " + getNombre() + " (ID: " + getId() + ")");
    }

    // Guardar en archivo CSV
    public void guardarEnCSV(String nombreArchivo) {
        File archivo = new File(nombreArchivo);
        boolean archivoExiste = archivo.exists();

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(archivo, true))) {
            if (!archivoExiste) {
                writer.write("Codigo,NombreProducto,Precio,CategoriaID,CategoriaNombre");
                writer.newLine();
            }

            writer.write(getCodigo() + "," + getNombreProducto() + "," + getPrecio() + "," + getId() + "," + getNombre());
            writer.newLine();

            System.out.println("Producto guardado en el archivo CSV correctamente.");
        } catch (IOException e) {
            System.err.println("Error al guardar en el archivo CSV: " + e.getMessage());
        }
    }

    public static List<Producto> leerDesdeCSV(String archivoCSV) {
        List<Producto> productos = new ArrayList<>();
        File archivo = new File(archivoCSV);
        if (!archivo.exists()) return productos;

        try (BufferedReader reader = new BufferedReader(new FileReader(archivo))) {
            String linea;
            reader.readLine(); // saltar encabezado
            while ((linea = reader.readLine()) != null) {
                String[] partes = linea.split(",");
                if (partes.length == 5) {
                    String codigo = partes[0];
                    String nombreProducto = partes[1];
                    double precio = Double.parseDouble(partes[2]);
                    int id = Integer.parseInt(partes[3]);
                    String nombreCategoria = partes[4];

                    Producto p = new Producto(codigo, nombreProducto, precio, id, nombreCategoria);
                    productos.add(p);
                }
            }
        } catch (IOException | NumberFormatException e) {
            System.out.println("Error al leer desde CSV: " + e.getMessage());
        }
        return productos;
    }

    public static void mostrarProductosDesdeCSV(String archivoCSV) {
        List<Producto> productos = leerDesdeCSV(archivoCSV);
        if (productos.isEmpty()) {
            System.out.println("No hay productos registrados en el CSV.");
        } else {
            for (Producto p : productos) {
                System.out.println("-------------------");
                p.mostrarResumen();
            }
        }
    }

    public static Producto buscarProductoPorCodigoCSV(String archivoCSV, String codigoBuscado) {
        List<Producto> productos = leerDesdeCSV(archivoCSV);
        for (Producto p : productos) {
            if (p.getCodigo().equalsIgnoreCase(codigoBuscado)) {
                return p;
            }
        }
        return null;
    }

    public static boolean eliminarProductoPorCodigoCSV(String archivoCSV, String codigoEliminar) {
        List<Producto> productos = leerDesdeCSV(archivoCSV);
        boolean eliminado = productos.removeIf(p -> p.getCodigo().equalsIgnoreCase(codigoEliminar));

        if (eliminado) {
            File archivo = new File(archivoCSV);
            try (BufferedWriter writer = new BufferedWriter(new FileWriter(archivo))) {
                writer.write("Codigo,NombreProducto,Precio,CategoriaID,CategoriaNombre");
                writer.newLine();
                for (Producto p : productos) {
                    writer.write(p.getCodigo() + "," + p.getNombreProducto() + "," + p.getPrecio() + "," + p.getId() + "," + p.getNombre());
                    writer.newLine();
                }
                System.out.println("Producto eliminado y archivo CSV actualizado.");
                return true;
            } catch (IOException e) {
                System.out.println("Error al actualizar el CSV: " + e.getMessage());
            }
        }
        return false;
    }
}

//arreglos y listas
//estudiar para esta semana 
//agregar leer y excepciones


    

